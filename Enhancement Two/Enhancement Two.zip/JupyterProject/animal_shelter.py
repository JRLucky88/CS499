from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):

        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31631
        DB = 'aac'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://localhost' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary
            return True    
        else:
            print("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD.
    def read(self, readData):
        if readData is not None:
            return self.database.animals.find(readData,{"_id":False})
    
        else:
            print('Nothing to read, because data parameter is empty')
            return False
        
# Create method to implement the U in CRUD.
    def update(self, searchData, updateData):
        if searchData is not None:
            return self.database.animals.update_many(searchData, {"$set": updateData})
           
        else:
            print('Nothing to update, because data parameter is empty')
            return False
        
#Create method to implement the D in CRUD.
    def delete(self, deleteData):
        if deleteData is not None:
            return self.database.animals.delete_one(deleteData)
        else:
            print("Nothing to delete, because data parameter is empty")
            return False
        
